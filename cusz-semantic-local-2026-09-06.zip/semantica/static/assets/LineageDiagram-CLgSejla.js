import{a as n,j as e}from"./query-vendor-CCrh9h3E.js";import{i as I,B as N,C as R}from"./style-Bhdr0FFh.js";import{b as S}from"./index-CzLRDQf_.js";import"./index-CVqD6U61.js";/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=[["path",{d:"M9 17H7A5 5 0 0 1 7 7h2",key:"8i5ue5"}],["path",{d:"M15 7h2a5 5 0 1 1 0 10h-2",key:"1b9ql8"}],["line",{x1:"8",x2:"16",y1:"12",y2:"12",key:"1jonct"}]],C=S("link-2",L),O=`
  .react-flow { background: var(--ws-bg, #060d1a); }
  .react-flow__node-group {
    background: rgba(74,163,255,0.04);
    border: 1px dashed rgba(74,163,255,0.18);
    border-radius: 10px;
  }
  .react-flow__node-default {
    background: rgba(6,13,26,0.92);
    color: var(--ws-text, #ddeeff);
    border: 1px solid rgba(74,163,255,0.22);
    border-radius: 8px;
    padding: 10px 12px;
    white-space: pre-wrap;
    font-size: 12px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
  }
  .react-flow__controls { background: rgba(6,13,26,0.9); border: 1px solid rgba(74,163,255,0.18); border-radius: 10px; }
  .react-flow__controls-button { background: transparent; border-color: rgba(74,163,255,0.15); color: var(--ws-text-muted, #5a7a9a); }
  .react-flow__controls-button:hover { background: rgba(74,163,255,0.1); color: var(--ws-text, #ddeeff); }
`;function $(){const[f,p]=n.useState([]),[m,g]=n.useState([]),[c,v]=n.useState(""),[o,b]=n.useState(""),[u,i]=n.useState(""),x=async r=>{if(!o)return;const d=await fetch(`/api/provenance/report?node_id=${encodeURIComponent(o)}&format=${r}`);if(!d.ok)return;const h=await d.blob(),a=window.URL.createObjectURL(h),s=document.createElement("a");s.href=a,s.download=`${o}_provenance.${r==="markdown"?"md":"json"}`,document.body.appendChild(s),s.click(),window.URL.revokeObjectURL(a),document.body.removeChild(s)},[k,j]=n.useState(o);return o!==k&&(j(o),i(""),p([]),g([])),n.useEffect(()=>{let r=!1;if(!o)return;const d=[{id:"group_agent",type:"group",position:{x:50,y:50},style:{width:800,height:120}},{id:"group_activity",type:"group",position:{x:50,y:200},style:{width:800,height:120}},{id:"group_entity",type:"group",position:{x:50,y:350},style:{width:800,height:120}}];return(async()=>{i("");try{const a=await fetch("/api/provenance?node_id="+encodeURIComponent(o));if(!a.ok){const t=await a.text();throw new Error(`HTTP ${a.status}: API Route missing or failed. ${t.substring(0,100)}`)}const s=a.headers.get("content-type");if(!s||!s.includes("application/json"))throw new Error("Backend returned non-JSON response (likely an HTML fallback).");const l=await a.json();a.status===207&&i(l.message||"Warning: Partial success loading lineage.");const w={group_agent:0,group_activity:0,group_entity:0},_=l.nodes.map(t=>{const y=w[t.parent_id]||0;return w[t.parent_id]=y+1,{id:t.id,data:{label:t.label+`
(`+t.prov_type+")"},position:{x:50+y*180,y:30},parentId:t.parent_id,extent:"parent",type:"default"}}),E=l.edges.map(t=>({id:t.id,source:t.source,target:t.target,label:t.label,animated:!0,style:{stroke:"#58a6ff"}}));r||(p([...d,..._]),g(E))}catch(a){i(a instanceof Error?a.message:"Failed to load lineage.")}})(),()=>{r=!0}},[o]),e.jsxs("div",{style:{width:"100%",height:"100%",position:"relative",background:"var(--ws-bg, #060d1a)"},children:[e.jsx("style",{children:O}),e.jsxs("div",{style:{position:"absolute",top:14,left:14,right:14,zIndex:10,display:"flex",gap:8,alignItems:"center",background:"rgba(4,10,18,0.88)",backdropFilter:"blur(14px)",padding:"8px 12px",borderRadius:12,border:"1px solid rgba(74,163,255,0.16)",boxShadow:"0 4px 20px rgba(0,0,0,0.4)"},children:[e.jsx("span",{className:"ws-eyebrow",style:{color:"var(--ws-accent, #4aa3ff)",marginRight:4},children:"PROV-O Lineage"}),e.jsx("input",{className:"ws-input",type:"text",placeholder:"Enter Node ID…",value:c,onChange:r=>v(r.target.value),onKeyDown:r=>{r.key==="Enter"&&b(c)},style:{width:200,padding:"6px 10px",fontSize:12}}),e.jsx("button",{className:"ws-btn ws-btn--primary",style:{padding:"6px 12px"},onClick:()=>b(c),children:"Trace"}),e.jsx("div",{style:{flex:1}}),e.jsx("button",{className:"ws-btn ws-btn--ghost",style:{padding:"6px 12px",fontSize:11},disabled:!o,onClick:()=>{x("json")},children:"Export JSON"}),e.jsx("button",{className:"ws-btn ws-btn--ghost",style:{padding:"6px 12px",fontSize:11},disabled:!o,onClick:()=>{x("markdown")},children:"Export MD"})]}),u?e.jsx("div",{style:{position:"absolute",top:60,left:14,right:14,zIndex:10,padding:12,borderRadius:14,color:"#ffb4c2",background:"rgba(255,157,175,0.1)",border:"1px solid rgba(255,157,175,0.18)"},children:u}):null,o?e.jsxs(I,{nodes:f,edges:m,fitView:!0,children:[e.jsx(N,{color:"rgba(74,163,255,0.08)",gap:24}),e.jsx(R,{})]}):e.jsxs("div",{className:"ws-empty",style:{height:"100%",paddingTop:72},children:[e.jsx("div",{className:"ws-empty-icon",children:e.jsx(C,{size:36,color:"var(--ws-accent)"})}),e.jsx("div",{className:"ws-empty-title",children:"PROV-O Lineage Viewer"}),e.jsx("div",{className:"ws-empty-body",children:"Enter a Node ID in the toolbar above and click Trace to view its W3C PROV-O lineage diagram."})]})]})}export{$ as LineageDiagram};
